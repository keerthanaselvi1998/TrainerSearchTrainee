package org.tms.services;
import org.tms.beans.Register;

public interface RegisterService {
	public boolean register(Register r);
}
