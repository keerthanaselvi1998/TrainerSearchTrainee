package org.tms.dao;



import org.tms.beans.TraineeClass;
public interface SearchTrainee {
     TraineeClass search(int userId);
}
